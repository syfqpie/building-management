from django.apps import AppConfig


class UnitsConfig(AppConfig):
    name = 'units'
