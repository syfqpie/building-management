from django.apps import AppConfig


class ProprietorsConfig(AppConfig):
    name = 'proprietors'
